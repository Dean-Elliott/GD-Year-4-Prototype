﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseCharacterParent : MonoBehaviour
{
    // Start is called before the first frame update
    protected virtual void Awake()
    {
        
    }

    // Update is called once per frame
    protected virtual void Update()
    {
        
    }
}
