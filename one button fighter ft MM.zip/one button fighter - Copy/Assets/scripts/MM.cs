﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;


public class MM : MonoBehaviour
{

    public Player[] players = new Player[4];
    public GameObject[] spawnPoints;


    public GameObject[] scoreTrackers;

    // Start is called before the first frame update
    void Start()
    {
        spawnPoints = GameObject.FindGameObjectsWithTag("SpawnPoint");
        //GameStart();
    }

    // Update is called once per frame
    void Update()
    {
        
        foreach (Player player in players)
        {
            if (!player.isActive)
            {
                SearchForNewPlayer();
                break;
            }
        }


    }

    void SearchForNewPlayer ()
    {
        foreach (KeyCode kcode in Enum.GetValues(typeof(KeyCode)))
        {
            if (Input.GetKeyDown(kcode))
            {
                bool keyUsed = false;
                String button = kcode.ToString();

                foreach (Player player in players)
                {
                    if (player.inputButton == button)
                    {
                        keyUsed = true;
                    }
                }


                if (keyUsed == false)
                {
                    foreach (Player player in players)
                    {
                        if (!player.isActive)
                        {
                            player.isActive = true;
                            player.inputButton = button;
                            player.Spawn(GetSpawnPosition());
                            break;
                        }
                    }
                }
            }
        }
    }
    IEnumerator UpdateUI()
    {
        return null;
    }

    Vector3 GetSpawnPosition()
        {


            // get the average postion of all the currently active players
            Vector3 spawnPosition = Vector3.zero;
            Vector3 avgPlayerPos = Vector2.zero;
            int livePlayers = 0;


            foreach (Player player in players)
            {
                if (player.character != null)
                {
                    avgPlayerPos += player.character.transform.position;
                    livePlayers++;
                }
            }

            avgPlayerPos = avgPlayerPos / livePlayers;



            //compare that average position to all the spawn points on the map 
            foreach (GameObject point in spawnPoints)
            {
                float distance = (avgPlayerPos - point.transform.position).magnitude;

                if (spawnPosition == Vector3.zero)
                {
                    Debug.Log("FoundPosition");
                    spawnPosition = point.transform.position;
                }
                else if (distance > (avgPlayerPos - spawnPosition).magnitude)
                {
                    spawnPosition = point.transform.position;
                }
            }
            return spawnPosition;
        }


        void GameStart()
        {

            foreach (Player player in players)
            {
                player.Spawn(GetSpawnPosition());
            }

            //TO DO CREATE SCORE BOARD

        }

        public void Kill(int KillerID, int VictimID)
        {
            Destroy(players[VictimID].character.gameObject);
            players[KillerID].Score++;
        }

        void CreateScoreBoard()
        {
            scoreTrackers = new GameObject[4];
            foreach (Player player in players)
            {
                if (player.isActive)
                {

                }
            }
        }


    
}

