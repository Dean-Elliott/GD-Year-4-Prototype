﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitBox : MonoBehaviour
{
    basicCharacter myController;

    private void Awake()
    {
        myController = GetComponentInParent<basicCharacter>();
    }

    //hardcoded, fix this
    //private void OnTriggerStay2D(Collider2D collision)
    //{
    //    if (collision.CompareTag("pointy1") && myController.myID == 2)
    //    {
    //        if (collision.GetComponentInParent<PlayerController>().isLethal || collision.GetComponentInParent<PlayerController>().alwaysLethal == true)
    //        {
    //            myController.rb.velocity = Vector2.zero;
    //            myController.myMatchManager.teleportPlayer(myController.gameObject);
    //        }
    //    }
    //    if (collision.CompareTag("pointy2") && myController.myID == 1)
    //    {
    //        if (collision.GetComponentInParent<PlayerController>().isLethal || collision.GetComponentInParent<PlayerController>().alwaysLethal == true)
    //        {
    //            myController.rb.velocity = Vector2.zero;
    //            myController.myMatchManager.teleportPlayer(myController.gameObject);
    //        }
    //    }
    //}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("weapon"))
        {
            BaseCharacter collisionPlayer = collision.gameObject.GetComponentInParent<BaseCharacter>();
            if (collisionPlayer.playerID != myController.playerID)
            {
                myController.matchManager.Kill(collisionPlayer.playerID, myController.playerID);
            }
        }
    }
}
