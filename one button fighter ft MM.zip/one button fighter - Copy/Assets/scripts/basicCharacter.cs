﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class basicCharacter : BaseCharacter
{
    private void FixedUpdate()
    {
        if (isButtonClickedDown)
        {
            Dash();
            isButtonClickedDown = false;
        }
        if (isButtonHeldUp)
        {
            RotateCharacter(char_initialRotationDirection, char_rotationSpeed);
        }
    }
}
