﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum rotationDirection { clockwise, counterClockwise, noRotation, unassigned };

public abstract class BaseCharacter : BaseCharacterParent
{
    [Header("player values")]
    public int playerID;
    public string inputButton;

    [Header("Input")]
    public bool isButtonClickedDown;
    public bool isButtonClickedUp;
    public bool isButtonHeldDown;
    public bool isButtonHeldUp;

    [Header("Stats")]
    public float char_mass;
    public float char_gravityScale;
    public rotationDirection char_initialRotationDirection = rotationDirection.clockwise;
    public float char_rotationSpeed;
    public float char_dashForce;
    public float char_linearDrag;

    [Header("Movement")]
    rotationDirection currentRotationDirection;
    float rotationSpeed;
    float dashForce;
    bool canZeroVelocity = true;

    [Header("Components and children")]
    Rigidbody2D myRigidBody2D;
    public GameObject rotatingChildObject; //rotate a child of the object with the rb2D so that the rb2D can have its rotation frozen, preventing unwanted torque

    //
    public MM matchManager;

    protected override sealed void Awake()
    {
        myRigidBody2D = GetComponentInParent<Rigidbody2D>();   
        myRigidBody2D.centerOfMass = Vector3.zero; //ensures center of mass is centered to prevent wobbling and unwanted behaviour
        onAwake();

        ///
        matchManager = GameObject.Find("MM").GetComponent<MM>();
        //
    }

    protected override sealed void Update()
    {
        getInputs();
    }

    public void onAwake() //specifically for overriding in new characters
    {
    }

    public void Dash()
    {
        SetVelocityToZero(canZeroVelocity);
        myRigidBody2D.AddForce(rotatingChildObject.transform.up * char_dashForce, ForceMode2D.Impulse);
    }

    public void SetVelocityToZero(bool arg_canZeroVelocity)
    {
        if (arg_canZeroVelocity == true)
        {
            myRigidBody2D.velocity = Vector2.zero;
        }
    }

    public void RotateCharacter(rotationDirection newRotationDirection, float rotationSpeed)
    {
        rotatingChildObject.transform.Rotate(new Vector3(0, 0, (rotationSpeed * rotationDirectionEnumToFloat(newRotationDirection) * Time.fixedDeltaTime)));
    }

    public float rotationDirectionEnumToFloat( rotationDirection newRotationDirection)
    {
        if(newRotationDirection == rotationDirection.clockwise)
        {
             return 1f;
        }
        else if (newRotationDirection == rotationDirection.counterClockwise)
        {
             return -1f;
        }
        else if (newRotationDirection == rotationDirection.noRotation)
        {
             return 0f;
        }
        else if (newRotationDirection == rotationDirection.unassigned)
        {
            return 0f;
            throw new System.Exception("rotation direction is unassigned!");
        }
        else return 0f;
    }

    public void getInputs() //updates Inputs
    {
        //if statements prevents missing inputs by ensuring that a press will not be overwritten false if the input is not used by the next update loop
        //button down this frame
        if (Input.GetButtonDown(inputButton) == true)
        {
            isButtonClickedDown = true;
        }
        //button up this frame
        if (Input.GetButtonUp(inputButton) == true)
        {
            isButtonClickedUp = true;
        }
        //button held down
        isButtonHeldDown = Input.GetButton(inputButton);
        //button held up
        isButtonHeldUp = !Input.GetButton(inputButton);
    }
}
