﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{

    public bool isActive;
    public string inputButton; 

    public int myID;

    public Color color;
    public GameObject CharacterPrefab;

    [HideInInspector]
    //public GameObject character;

    [Header("Stats")]
    public int Score;
    public int Deaths;
    public int Kills;

    public BaseCharacter character;

    private void Update()
    {
       
    }

    //private void CheckInput()
    //{
    //    if (Input.GetButtonDown(inputButton))
    //    {
    //        /// call down method
    //    }

    //    if (Input.GetButton(inputButton))
    //    {
    //        //call held method
    //    }

    //    if (Input.GetButtonUp(inputButton))
    //    {
    //        //call up method
    //    }
    //}

    public void Spawn (Vector3 spawnPosition)
    {
        if (character == null)
        {
            character = Instantiate(CharacterPrefab, this.transform).GetComponent<BaseCharacter>();
            character.transform.position = spawnPosition;
            character.inputButton = inputButton;
            character.playerID = myID;
            character.GetComponentInChildren<SpriteRenderer>().color = color;
        }
    }
}
