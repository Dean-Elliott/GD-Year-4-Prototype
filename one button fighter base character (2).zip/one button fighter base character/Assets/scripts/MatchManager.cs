﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MatchManager : MonoBehaviour
{
    public GameMode selectedGameMode;

    public void onGamemode()
    {
        
    }



}
