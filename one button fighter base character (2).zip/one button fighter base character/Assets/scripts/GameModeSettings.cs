﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Game mode Setting", menuName = "Game Mode Setting")]
public class GameModeSettings : ScriptableObject
{

}