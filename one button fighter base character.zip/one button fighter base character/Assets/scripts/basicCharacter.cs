﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class basicCharacter : BaseCharacter
{
    private void FixedUpdate()
    {
        if (isButtonDownThisFrame)
        {
            Dash();
            isButtonDownThisFrame = false;
        }
        if (isButtonHeldUp)
        {
            RotateCharacter(currentRotationDirection, char_rotationSpeed);
        }
    }
}
