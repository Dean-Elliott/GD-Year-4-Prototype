﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

[System.Serializable]
public class OnPlayerCollisionEvent : UnityEvent<int, int> { }

public class HitBox : MonoBehaviour
{
    public OnPlayerCollisionEvent OnPlayerCollision = new OnPlayerCollisionEvent();
    int myPlayerID;
    GameMode activeGameMode;

    private void Awake()
    {
        myPlayerID = GetComponentInParent<Player>().playerID;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("weapon"))
        {
            Player collisionPlayer = collision.gameObject.GetComponentInParent<Player>();
            if (collisionPlayer.playerID != myPlayerID)
            {
                print("col detected");
                OnPlayerCollision.Invoke(collisionPlayer.playerID, myPlayerID);
            }
        }
    }
}
