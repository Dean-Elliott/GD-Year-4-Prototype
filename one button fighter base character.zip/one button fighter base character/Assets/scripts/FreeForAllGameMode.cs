﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FreeForAllGameMode : GameMode
{

    //public GameObject[] players;
    public int[] playerScores;
    public HitBox hitboxPlayerCollision;

    public GameObject[] initialSpawnPoints;
    public GameObject[] spawnPoints;

    public override void AtEndOfOnEnableOverride()
    {
        SpawnAllPlayers();
    }

    public void SpawnAllPlayers()
    {
        //always spawn at same spots
        foreach (KeyValuePair<int, GameObject> player in playerObjectByID)
        {
            playerObjectByID[player.Key] = Instantiate(Instantiate(GameManager.gameManagerInstance.allCharacterPrefabs[playerCharacterSelections[player.Key]], initialSpawnPoints[player.Key].transform.position, Quaternion.identity));
        }
    }

    public void RespawnPlayer(int PlayerToRespawnID)
    {
        GameObject furthestAwaySpawnPoint = FindNodeFarthestFromAnyActivePlayer(spawnPoints);

        playerObjectByID[PlayerToRespawnID] = Instantiate(GameManager.gameManagerInstance.allCharacterPrefabs[playerCharacterSelections[PlayerToRespawnID]], furthestAwaySpawnPoint.transform.position, Quaternion.identity);
        playerObjectByID[PlayerToRespawnID].GetComponent<Player>().inputButton = PlayerToRespawnID.ToString();
        playerObjectByID[PlayerToRespawnID].GetComponent<Player>().playerID = PlayerToRespawnID;
    }

    public override void CharacterCollision(int attackerPlayerID, int VictimPlayerID)
    {
        playerScores[attackerPlayerID] += 1;

        playerObjectByID[VictimPlayerID].GetComponentInChildren<HitBox>().OnPlayerCollision.RemoveListener(CharacterCollision);
        Destroy(playerObjectByID[VictimPlayerID]);

        RespawnPlayer(VictimPlayerID);

        print(playerScores[0] + "  " +  playerScores[1]);
    }
}
