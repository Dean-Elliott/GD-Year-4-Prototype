﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class GameMode : MonoBehaviour
{
    public Dictionary<int, GameObject> playerObjectByID;

    public int[] allowableNumberOfPlayers;
    public bool canShowMapSelectionScreen;
    public bool canShowTeamSelectionScreen;
    public bool canShowCharacterSelectionScreen;

    public int[] playerCharacterSelections;


    private void OnEnable()
    {
        foreach (KeyValuePair<int, GameObject> player in playerObjectByID)
        {
            if (player.Value != null)
            {
                player.Value.GetComponentInChildren<HitBox>().OnPlayerCollision.AddListener(CharacterCollision);
            }
        }
        AtEndOfOnEnableOverride();
    }

    public virtual void AtEndOfOnEnableOverride()
    {

    }

    private void OnDisable()
    {
        foreach (KeyValuePair<int, GameObject> player in playerObjectByID)
        {
            if (player.Value != null)
            {
                player.Value.GetComponentInChildren<HitBox>().OnPlayerCollision.RemoveListener(CharacterCollision);
            }
        }
    }

    public virtual void CharacterCollision(int attackerPlayerID, int VictimPlayerID)
    {
    }

    public virtual GameObject FindNodeFarthestFromAnyActivePlayer(GameObject[] nodes)
    {
        //find the distance to the closest live player for all spawn points
        float[] spawnPointClosestDistances = new float[nodes.Length];
        for (int i = 0; i < nodes.Length; i++)
        {
            float spawnPointDistanceToClosestLivingPlayer = Mathf.Infinity;
            foreach (KeyValuePair<int, GameObject> player in playerObjectByID)
            {
                if (Vector2.Distance(nodes[i].transform.position, player.Value.transform.position) < spawnPointDistanceToClosestLivingPlayer)
                {
                    spawnPointDistanceToClosestLivingPlayer = Vector2.Distance(nodes[i].transform.position, player.Value.transform.position);
                }
            }
            spawnPointClosestDistances[i] = spawnPointDistanceToClosestLivingPlayer;
        }

        //compare distances to closest live player for all spawn points, selecting the spawn point with the largest distance as the new spawn point
        float longestDistanceToLivingPlayer = 0f;
        GameObject furthestAwaySpawnPoint = null;
        for (int i = 0; i < spawnPointClosestDistances.Length; i++)
        {
            if (spawnPointClosestDistances[i] > longestDistanceToLivingPlayer)
            {
                longestDistanceToLivingPlayer = spawnPointClosestDistances[i];
                furthestAwaySpawnPoint = nodes[i];
            }
        }
        return furthestAwaySpawnPoint;
    }
}
